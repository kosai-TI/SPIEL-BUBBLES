import pygame
import time
import random
import math
pygame.init()
pygame.font.init() 
#Farben
GELB = (255,255,0)
ORANGE=(255,102,0)
CYAN = (0,255,255)
SCHWARZ = ( 0, 0, 0)
WEISS = ( 255, 255, 255)
GRÜN = ( 0, 255, 0) 
ROT = ( 255, 0, 0) 
BLAU = (0,0,255)
SILBER = (211,211,211)
KILLCOLOR = ROT
COLLATIONCOLOR = GRÜN
OPTION1COLOR = GELB
OPTION2COLOR = CYAN
OPTION3COLOR = SCHWARZ

#Spieloptionen
screensizex=700
screensizey=500
#Hintergrundfarbe
screencolor=GELB 
circlelinewidth = 2        
minr = 5                     # Minimum R
maxr = 15                    # Maximum R
farfromedge = 100            
circlecolor = BLAU 
carryOn = True
maxcircle =3 # Maximale Zahl von den Kreißen
clocktick = 60    #10
cursor_img = pygame.image.load("cursor.png")

class classcircle:
	def __init__(self,x,y,r,wachstum):
		self.x=x
		self.y=y
		self.r=r
		self.wachstum=wachstum
	def setoption(self,circlelinewidth,circlecolor):
		self.width = circlelinewidth
		self.color = circlecolor
	def getVal(self):
		return self.val
	def checkforcollation(self):
		print("Collation")
	def checkforcollationwithscreen(self):
		print("Collation with screen")
	def zerplatzen(self):
		self.width=0
		self.color = (255,0,0)


# METHODEN 
OPTION1COLOR = GELB         #weiter
OPTION2COLOR = CYAN           #End
OPTION3COLOR = SCHWARZ          #neu spielen
def getxyr(minr,maxr,screensizex,screensizey,farfromedge,listofcircles):
    x = 0 
    y =0 
    r = 10 
    wachstum = 0
    c = classcircle(x,y,r,wachstum)
    while checkxyr(x,y,r,screensizex,screensizey,farfromedge,listofcircles) != True:
        x = random.randint(0, screensizex)
        y = random.randint(0, screensizey)
        r = random.randint(minr,maxr)
        wachstum = random.randint(1,10)
        c = classcircle(x,y,r,wachstum)
    return c
def checkxyr(x,y,r,screensizex,screensizey,farfromedge,listofcircles):
    if colltionwithborder(x,y,r,screensizex,screensizey,farfromedge) == False:
        return False
    for circle in listofcircles:
        w = math.pow((math.pow((x-circle.x),2)+math.pow((y-circle.y),2)),0.5)
        if w -r-circle.r <= 10:
            return False
    return True

def distance (x1,y1,x2,y2):
    w = math.pow((math.pow((x1-x2),2)+math.pow((y1-y2),2)),0.5)
    return w
def colltionwithborder(x,y,r,screensizex,screensizey,farfromedge):
    if x+r >= screensizex-farfromedge:
        return False
    if x-r <=farfromedge:
        return False
    if y+r >= screensizey-farfromedge:
        return False
    if y-r <= farfromedge:
        return False
    
    return True


def checkcollation(circle1,circle2):
    w = math.pow((math.pow((circle1.x-circle2.x),2)+math.pow((circle1.y-circle2.y),2)),0.5)
    if circle1.color != BLAU or circle2.color != BLAU:
        return ("")
    if w == 0:
        pass
    if w == circle1.r + circle2.r:
        pass
    if w < circle1.r + circle2.r and w>0:
        return("collation")
    if w> circle1.r + circle2.r:
        pass
def checkmouseclick(circle,mousex,mousey):
    w = math.pow((math.pow((circle.x-mousex),2)+math.pow((circle.y-mousey),2)),0.5)
    if w == circle.r:
        pass
    if w < circle.r:
        return("inside")
    if w> circle.r:
        pass
def pausefunction(listofcircles,screensizex,screensizey,*args):
    # Farbe ändern
    for c in listofcircles:
        c.setoption(0,(169,169,169))
    # wenn das Spiel pausiert
    # Die Option Button einfügen
    optioncircle = classcircle(screensizex*3/4,screensizey*2/3,50,0)
    optioncircle.setoption(0,OPTION2COLOR)
    listofcircles.append(optioncircle)
    if args[0] == "pause":
        optioncircle = classcircle(screensizex/4,screensizey*2/3,50,0)
        optioncircle.setoption(0,OPTION1COLOR)
        listofcircles.append(optioncircle)
    # wenn man verliert
    if args[0] == "lost": 
        optioncircle = classcircle(screensizex/2,screensizey*3/4,75,0)
        optioncircle.setoption(0,ORANGE)
        listofcircles.append(optioncircle)
        optioncircle = classcircle(screensizex/4,screensizey*2/3,50,0)
        optioncircle.setoption(0,OPTION3COLOR)
        listofcircles.append(optioncircle)

def readfromfile():
    f = open("bestelist.txt","r")
    punkte = []
    for x in f:
        if x != "":
            punkte.append(x.split(":"))
    f.close()
    punkte.sort(key = lambda x:int(x[1]),reverse=True)
    return punkte
def writetofile(punktelist):
    f = open("bestelist.txt","w")
    for x in punktelist:
        f.write(x[0]+":"+x[1])
    f.close()




# Bildschirm
clock = pygame.time.Clock()
screen = pygame.display.set_mode((screensizex, screensizey))
pygame.display.set_caption("My First Game")
listofcircles = []
pause = False
punkte =0
nameeingeben= False
playername = "Player"
written = True
endtick = 0 
# Hier fängt das Spiel an
while carryOn:
    for event in pygame.event.get():
        if event.type == pygame.QUIT: 
              carryOn = False 
        if event.type == pygame.KEYDOWN:
            if event.key == 13:
                nameeingeben = False
                punktelist = readfromfile()
                punktelist.append((playername,f'{punkte:.0f}\n'))
                punktelist.sort(key = lambda x:int(x[1]),reverse=True)
                punktelist.remove(punktelist[len(punktelist)-1])
                writetofile(punktelist)
            if event.key == 8:
                if nameeingeben == True:
                    playername = playername[:-2]
            if nameeingeben == True:
                playername += chr(event.key)
                playername = ''.join(e for e in playername if e.isalnum())
    # P Taste einfügen
            if event.key == pygame.K_p and nameeingeben == False: # Wenn man auf Pause button drückt
                pause = True
                pausefunction(listofcircles,screensizex,screensizey,"pause")
                screencolor=SILBER 
    # Maus
        if event.type == pygame.MOUSEBUTTONUP:
           if event.button == 3:
               pause = True
               pausefunction(listofcircles,screensizex,screensizey,"pause")
               screencolor=SILBER 
           if event.button == 1:
                mousex = pygame.mouse.get_pos()[0]
                mousey = pygame.mouse.get_pos()[1]
                for circle in listofcircles:
                    if checkmouseclick(circle,mousex,mousey) == "inside":
                        if circle.color == BLAU:
                            endtick = pygame.time.get_ticks() + 150
                            myfont = pygame.font.SysFont('Comic Sans MS', 14)
                            einzelnpunkt = myfont.render(f'+{circle.r:.2f}', False, (0, 0, 0))
                            einzelnpunkt_rect = einzelnpunkt.get_rect(center = (circle.x,circle.y))          

                            circle.zerplatzen()
                            pygame.mixer.Sound.play(pygame.mixer.Sound("click.wav"))
                            punkte += circle.r
                        # weiter
                        if circle.color == OPTION1COLOR:
                            pause = False
                            # löscht OPTION kreisen
                            l = len(listofcircles)
                            listofcircles.remove(listofcircles[l-1])
                            l = len(listofcircles)
                            listofcircles.remove(listofcircles[l-1])
                            screencolor=GELB 
                            # Farbe wird Blau
                            for circle in listofcircles:
                                circle.width = circlelinewidth
                                circle.color = BLAU 
                        # beenden
                        if circle.color == OPTION2COLOR:
                            carryOn = False
                        # NEU spielen
                        if circle.color == OPTION3COLOR:
                            listofcircles.clear()
                            screencolor=GELB 
                            punkte = 0
                            written=False
                            pause = False
                        # NAME EINGEBEN 
                        if circle.color == ORANGE:
                            nameeingeben = True
    #überpruft COLLATION 
    # mit screen borders 
    for circle in listofcircles:
        if colltionwithborder(circle.x,circle.y,circle.r,screensizex,screensizey,0) != True  and pause == False:
            pausefunction(listofcircles,screensizex,screensizey,"lost")
            pygame.mixer.Sound.play(pygame.mixer.Sound("border.wav"))
            pause=True
                            
    # Mit anderen Kreisen 
    for circle1 in listofcircles:
        for circle2 in listofcircles:
            if checkcollation(circle1,circle2) == "collation" and pause == False:
                pausefunction(listofcircles,screensizex,screensizey,"lost")
                screencolor = SILBER 
                pygame.mixer.Sound.play(pygame.mixer.Sound("circles.wav"))
                pause = True
               
    # Ein Kreis zur Liste hinzufügen, nachdem überprüfen von der Kreisenanzal
    if len(listofcircles)  < maxcircle and pause == False:
        c = getxyr(minr,maxr,screensizex, screensizey,farfromedge,listofcircles)
        c.setoption(circlelinewidth,circlecolor)
        listofcircles.append(c)
        pygame.mixer.Sound.play(pygame.mixer.Sound("create.wav"))
    

    # Kreis wachstum
    if pause == False:
        for circle in listofcircles:
            circle.r += circle.wachstum/30
            circle.wachstum += circle.wachstum/60
    # CLEAR Bildschirm
    screen.fill(screencolor)
    # Alle Kreisen 
    for circle in listofcircles:
        pygame.draw.circle(screen,circle.color,(circle.x,circle.y),circle.r,width=circle.width)
    # Alle Punkte
    myfont = pygame.font.SysFont('Comic Sans MS', 18)
   # if pause == False:
    textsurface = myfont.render(f'Punkte :  + {punkte:.2f}', False, (0, 0, 0))
    screen.blit(textsurface,(0,0))
    
    
    #Beste List
    c = listofcircles[len(listofcircles)-1]
    if pause == True and c.color == SCHWARZ and nameeingeben == False:
        # if written == False:
        #     punktelist = readfromfile()
        #     if playername == "":
        #         playername = "Player"
        #     punktelist.append((playername,f'{punkte:.0f}\n'))
        #     punktelist.sort(key = lambda x:int(x[1]),reverse=True)
        #     punktelist.remove(punktelist[len(punktelist)-1])
        #     writetofile(punktelist)
        #     written = True
        spacebetweenlines = 40   
        for i in range(0,5):
            punktelist = readfromfile()
            x = ''.join(e for e in punktelist[i][0] if e.isalnum()) +" : " + ''.join(e for e in punktelist[i][1] if e.isalnum())
            text = myfont.render(x, False, SCHWARZ)
            text_rect = text.get_rect(center = (screensizex/2,screensizey/5+spacebetweenlines*i))          
            screen.blit(text,text_rect)
    #WRITE BUTTONS CAPTION 
    def showtext(text,color):
        text = myfont.render(text, False, color)
        text_rect = text.get_rect(center = (c.x,c.y))          
        screen.blit(text,text_rect) 
    for c in listofcircles:
        if c.color == GELB: 
            showtext("Weiter",SCHWARZ)
        if c.color == SCHWARZ: 
            showtext("NEU",WEISS)
        if c.color == CYAN: 
            showtext("Benden",SCHWARZ)
        if c.color == ORANGE: 
            if playername == "Player":
                showtext("Name eingeben",SCHWARZ)
            if playername != "" and playername != "Player":
                showtext(playername,SCHWARZ)
    # ändere CURSOR 
    mousex = pygame.mouse.get_pos()[0]
    mousey = pygame.mouse.get_pos()[1]
    cursor_img_rect = cursor_img.get_rect()
    cursor_img_rect.center = pygame.mouse.get_pos() 
    for circle in listofcircles:
        if checkmouseclick(circle,mousex,mousey) == "inside":
            if circle.color == BLAU: 
                pygame.mouse.set_visible(False)
                screen.blit(cursor_img, cursor_img_rect) # cursor
                break
        elif checkmouseclick(circle,mousex,mousey) != "inside":
            pygame.mouse.set_visible(True)

    if(endtick > pygame.time.get_ticks()):
        screen.blit(einzelnpunkt,einzelnpunkt_rect)
    else:
        einzelnpunkt=None
        einzelnpunkt_rect = None
    # Bildschirm aktualisieren
    pygame.display.flip()  
    # LIMIT fps
    clocktick = clocktick +0.1
    if clocktick >= 30:
        clocktick =30
    clock.tick(clocktick)

    for circle in listofcircles:
        if circle.width==0 and circle.color == KILLCOLOR:
            listofcircles.remove(circle)
            
pygame.quit()


